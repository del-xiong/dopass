document.getElementById("changepwchange").innerHTML=gs("Change");document.getElementById("changepwclose").innerHTML=gs("Close");
