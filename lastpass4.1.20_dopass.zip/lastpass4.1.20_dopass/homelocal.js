document.location.href="homelocal2.html";
