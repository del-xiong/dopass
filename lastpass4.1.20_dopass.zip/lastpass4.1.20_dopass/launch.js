dispatch_message("launch",{aid:getQueryVariable("aid")});
