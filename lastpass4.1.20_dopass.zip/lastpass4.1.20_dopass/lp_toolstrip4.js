sr(document,"notifychangeconfirmbtn","value","Confirm");sr(document,"notifychangesavenewsitebtn","value","Save New Site");
