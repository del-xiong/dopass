document.getElementById("sesameauth")&&(document.getElementById("sesameauth").innerHTML=gs("Authenticate"));
